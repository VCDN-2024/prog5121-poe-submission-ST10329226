package login;


import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeAll;
/**
 *
 * @author goven
 */
public class LoginApplicationTest {
    
    private LoginApplication instance;
    
    public LoginApplicationTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
        instance = new LoginApplication();
    }
    
    @AfterEach
    public void tearDown() {
    }

    @Test
    public void testIsValidUsername() {
        System.out.println("isValidUsername");
        String username = "validUsername";
        boolean expResult = true;
        boolean result = instance.isValidUsername(username);
        assertEquals(expResult, result);
    }

    @Test
    public void testIsValidPassword() {
        System.out.println("isValidPassword");
        String password = "validPassword123";
        boolean expResult = true;
        boolean result = instance.isValidPassword(password);
        assertEquals(expResult, result);
    }
    
    @Test
    public void testGetDevelopers() {
        System.out.println("getDevelopers");
        String[] expResult = {"Mike Smith", "Edward Harrison", "Samantha Paulson", "Glenda Oberholzer"};
        String[] result = instance.getDevelopers();
        assertArrayEquals(expResult, result);
    }

    @Test
    public void testGetLongestTask() {
        System.out.println("getLongestTask");
        String expResult = "Glenda Oberholzer, 11";
        String result = instance.getLongestTask();
        assertEquals(expResult, result);
    }

    @Test
    public void testsearchTaskByName() {
        System.out.println("searchTask");
        String taskName = "Create Login";
        String expResult = "Mike Smith, Create Login";
        String result = instance.searchTask(taskName);
        assertEquals(expResult, result);
    }

    @Test
    public void testGetTasksByDeveloper() {
        System.out.println("getTasksByDeveloper");
        String developer = "Samantha Paulson";
        String[] expResult = {"Create Reports"};
        String[] result = instance.getTasksByDeveloper(developer);
        assertArrayEquals(expResult, result);
    }

    @Test
    public void testdeleteTaskByName() {
        System.out.println("deleteTask");
        String taskName = "Create Reports";
        boolean expResult = true;
        boolean result = instance.deleteTask(taskName);
        assertTrue(result);
    }

    @Test
    public void testDisplayReport() {
        System.out.println("displayReport");
        String expResult = "Developer: Mike Smith, Task: Create Login, Duration: 5, Status: To Do\n" +
                           "Developer: Edward Harrison, Task: Create Add Features, Duration: 8, Status: Doing\n" +
                           "Developer: Samantha Paulson, Task: Create Reports, Duration: 2, Status: Done\n" +
                           "Developer: Glenda Oberholzer, Task: Add Arrays, Duration: 11, Status: To Do\n";
        String result = instance.displayReport();
        assertEquals(expResult, result);
    }
    
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        LoginApplication.main(args);
    }
}