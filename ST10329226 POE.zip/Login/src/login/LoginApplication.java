
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package login;

import javax.swing.JOptionPane;
import java.util.HashMap;
import java.util.ArrayList;

public class LoginApplication extends javax.swing.JFrame {
    private int numTasks;
    private boolean isLoggedIn = false;
    private final HashMap<String, String> registeredUsers;
    final HashMap<Integer, Task> tasks; // Stores tasks with their IDs
    private static int taskCounter = 0; // Keeps track of the total number of tasks

    
    
    // Method to display the numeric menu
     private final ArrayList<String> developerNames = new ArrayList<>();
     private final ArrayList<String> taskNames = new ArrayList<>();
    private final ArrayList<String> taskDescriptions = new ArrayList<>();
    private final ArrayList<String> developerDetails = new ArrayList<>();
    private final ArrayList<Integer> taskDurations = new ArrayList<>();
    private final ArrayList<String> taskStatuses = new ArrayList<>();
    private final ArrayList<String> taskIDs = new ArrayList<>();
    
    //Menu when logged in
private int displayMenu() {
    String[] options = {"1) Add tasks", "2) Show report", "3)  Quit"};
    return JOptionPane.showOptionDialog(null, "Choose an option:", "Menu", JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE, null, options, options[0]);
}
//unit tests, I have all the correct information but the tests always give 0%

    String getLongestTask() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    String searchTask(String taskName) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    String[] getTasksByDeveloper(String developer) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    boolean deleteTask(String taskName) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    String displayReport() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    String[] getDevelopers() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }


    //when adding a task
     public class Task {
         
    private final String taskName;
    private final String taskDescription;
    private final String developerDetails;
    private final int taskDuration;
    private final String taskStatus;
    private final int taskId;
   
    
//when adding a task
    public Task(String taskName, String taskDescription, String developerDetails, int taskDuration, String taskStatus) {
        this.taskName = taskName;
        this.taskDescription = taskDescription;
        this.developerDetails = developerDetails;
        this.taskDuration = taskDuration;
        this.taskStatus = taskStatus;
        this.taskId = ++taskCounter;
        
    }

    
    // Method to ensure that the task description is not more than 50 characters
    public boolean checkTaskDescription() {
        return taskDescription.length() <= 50;
    }
    
    

    // Method to create and return the taskID
  public String createTaskID() {
            String taskID = taskName.substring(0, 2).toUpperCase() + ":" + taskId + ":" + developerDetails.substring(developerDetails.length() - 3).toUpperCase();
            return taskID;
        }


    // Method to return the full task details
    public String printTaskDetails() {
        String taskID = createTaskID();
        return  "Task Status: " + taskStatus + "\n" +
                "Developer Details: " + developerDetails + "\n" +
               "Task Number: " + taskId + "\n" +
                "Task Name: " + taskName + "\n" +
                "Task Description: " + taskDescription + "\n" +
                "Task ID: " + taskID + "\n" +
                "Duration: " + taskDuration + " hours";
    }
    
    public int getTaskId() {
            return taskId;
    }
    
   public int getTaskDuration() {
            return taskDuration;
    // Method to return the total combined hours of all entered tasks

     
    }
    public String getTaskName() {
            return taskName;
        }

        public String getDeveloperDetails() {
            return developerDetails;
        }

        public String getTaskStatus() {
            return taskStatus;
        }
    
    }
     
    public LoginApplication() {
        initComponents();
        registeredUsers = new HashMap<>();
        tasks = new HashMap<>();
        populateTestData();
       
    }
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor. This code cannot be edited or erased 
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jTextField1 = new javax.swing.JTextField();
        jPasswordField1 = new javax.swing.JPasswordField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel1.setText("Username");

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel2.setText("Password");

        jButton1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButton1.setText("Register");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButton2.setText("Login");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jPasswordField1.setText("jPasswordField1");
        jPasswordField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jPasswordField1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jButton1)
                        .addGap(18, 18, 18)
                        .addComponent(jButton2))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, 70, Short.MAX_VALUE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPasswordField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(172, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(102, 102, 102)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jPasswordField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1)
                    .addComponent(jButton2))
                .addContainerGap(96, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

     // Method to add tasks
    private void addTasks() {
        int totalDuration = 0; // Variable to keep track of the total duration
        
        for (int i = 0; i < numTasks; i++) {
            String taskName = JOptionPane.showInputDialog("Enter Task Name:");
            String taskDescription = JOptionPane.showInputDialog("Enter Task Description (not more than 50 characters):");
            // Validate task description length
            if (taskDescription.length() <= 50) {
                
                // Get developer details, task duration, and task status from user input
                String developerDetails = JOptionPane.showInputDialog("Enter Developer Details:");
                int taskDuration = Integer.parseInt(JOptionPane.showInputDialog("Enter Task Duration in hours:"));
                String taskStatus = JOptionPane.showInputDialog("Enter Task Status (To Do, Done, Doing):");

                // Creates Task objects
              Task task = new Task(taskName, taskDescription, developerDetails, taskDuration, taskStatus);
                tasks.put(task.getTaskId(), task);

                // Populate arrays
                developerNames.add(developerDetails);
                taskNames.add(taskName);
                taskIDs.add(task.createTaskID());
                taskDurations.add(taskDuration);
                taskStatuses.add(taskStatus);

                JOptionPane.showMessageDialog(this, task.printTaskDetails());
                
            // Displays task details

            // Accumulates the total duration
             totalDuration += taskDuration;
                // Displays task details
 
            } else {
                JOptionPane.showMessageDialog(this, "Please enter a task description of less than 50 characters");
                i--; 
            }
        }
        // message to show total hours and tasks captured 
        JOptionPane.showMessageDialog(this, "Total Duration of All Tasks: " + totalDuration + " hours");
        JOptionPane.showMessageDialog(this, "All Task successfully captured");

    }
// this bit of code is in the show report, allows the users to select an option 
   private void showReport() {
    String[] options = {"1) Tasks with 'Done' status", "2) Task with longest duration", 
                        "3) Search Task by Name", "4) Search Tasks by Developer",
                        "5) Delete Task by Name", "6) Full Task Report", "7) Back to Main Menu"};
    int choice = JOptionPane.showOptionDialog(null, "Choose a report option:", "Reports Menu", 
                                              JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE, 
                                              null, options, options[0]);
    switch (choice) {
        case 0:
            showDoneTasks();
            break;
        case 1:
            showLongestTask();
            break;
        case 2:
            searchTaskByName();
            break;
        case 3:
            searchTasksByDeveloper();
            break;
        case 4:
            deleteTaskByName();
            break;
        case 5:
            showFullReport();
            break;
        case 6:
            return;
        default:
            JOptionPane.showMessageDialog(this, "Invalid choice. Please try again.");
            showReport();
            break;
    }
}
   //shows the report of all data captured 
   private void showFullReport() {
    StringBuilder report = new StringBuilder("Full Task Report:\n\n");

    for (Task task : tasks.values()) {
        report.append(task.printTaskDetails()).append("\n\n");
    }

    JOptionPane.showMessageDialog(this, report.toString());
}
   

    private void showDoneTasks() {
        // Display Developer, Task Names, and Task Duration for tasks with status 'Done'
        StringBuilder report = new StringBuilder("Tasks with status 'Done':\n\n");
        for (int i = 0; i < taskStatuses.size(); i++) {
            if (taskStatuses.get(i).equalsIgnoreCase("Done")) {
                report.append("Developer: ").append(developerNames.get(i))
                      .append(", Task Name: ").append(taskNames.get(i))
                      .append(", Task Duration: ").append(taskDurations.get(i)).append(" hours\n");
            }
        }
        JOptionPane.showMessageDialog(this, report.toString());
    }

    private void showLongestTask() {
        // Display the Developer and Duration of the task with the longest duration
        int maxDurationIndex = 0;
        for (int i = 1; i < taskDurations.size(); i++) {
            if (taskDurations.get(i) > taskDurations.get(maxDurationIndex)) {
                maxDurationIndex = i;
            }
        }
        JOptionPane.showMessageDialog(this, "Task with longest duration:\nDeveloper: " 
                + developerNames.get(maxDurationIndex) + ", Duration: " 
                + taskDurations.get(maxDurationIndex) + " hours");
    }

    private void searchTaskByName() {
        // Search for a task by its name
        String taskName = JOptionPane.showInputDialog("Enter Task Name to search:");
        for (int i = 0; i < taskNames.size(); i++) {
            if (taskNames.get(i).equalsIgnoreCase(taskName)) {
                JOptionPane.showMessageDialog(this, "Task found:\nTask Name: " 
                        + taskNames.get(i) + ", Developer: " + developerNames.get(i) 
                        + ", Task Status: " + taskStatuses.get(i));
                return;
            }
        }
        JOptionPane.showMessageDialog(this, "Task not found.");
    }

    private void searchTasksByDeveloper() {
          if (developerNames.isEmpty()) {
        JOptionPane.showMessageDialog(this, "No tasks have been added yet.");
        return; //displays message task not added 
    }
          
        // Search for tasks assigned to a developer
        String developerName = JOptionPane.showInputDialog("Enter Developer Name to search tasks:");
         if (developerName == null || developerName.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Developer name cannot be empty.");
        return;
         }
        StringBuilder result = new StringBuilder("Tasks assigned to " + developerName + ":\n\n");
        boolean taskFound = false;
        for (int i = 0; i < developerNames.size(); i++) {
            if (developerNames.get(i).equalsIgnoreCase(developerName)) {
                taskFound = true;
               result.append("Task Name: ").append(taskNames.get(i))
                  .append(", Task Status: ").append(taskStatuses.get(i)).append("\n");
        }
            
        } if (taskFound) {
        JOptionPane.showMessageDialog(this, result.toString());
    }
    else {
        JOptionPane.showMessageDialog(this, "No tasks found for developer: " + developerName);
    }}

    private void deleteTaskByName() {
        // Delete a task by its name
        String taskName = JOptionPane.showInputDialog("Enter Task Name to delete:");
        for (int i = 0; i < taskNames.size(); i++) {
            if (taskNames.get(i).equalsIgnoreCase(taskName)) {
                developerNames.remove(i);
                taskNames.remove(i);
                taskIDs.remove(i);
                taskDurations.remove(i);
                taskStatuses.remove(i);
       Task taskToDelete = null;
            for (Task task : tasks.values()) {
                if (task.getTaskName().equalsIgnoreCase(taskName)) {
                    taskToDelete = task;
                    break;
                }
            }
            if (taskToDelete != null) {
                tasks.remove(taskToDelete.getTaskId());
            }

            JOptionPane.showMessageDialog(this, "Task '" + taskName + "' successfully deleted.");
            return; //message to show task is deleted 
        }
    }
    JOptionPane.showMessageDialog(this, "Task not found.");
}
    
    
    
    
    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // handling code
         // Register button action
        String username = jTextField1.getText();
        String password = String.valueOf(jPasswordField1.getPassword());

 if (isValidUsername(username)) {
        // registration process for new users 
        
         if (registeredUsers.containsKey(username)) {
                JOptionPane.showMessageDialog(this, "Username already exists. Please choose another one.");// display message
            } else {
             registeredUsers.put(username, password);
        JOptionPane.showMessageDialog(this, "Registration successful for user: " + username);// display message
    }//GEN-LAST:event_jButton1ActionPerformed
 }
 else {
        JOptionPane.showMessageDialog(this, "Username must contain an underscore (_) and be no longer than 5 characters.");// display message
    }
 
    }  

// Method to validate username
boolean isValidUsername(String username) {
    return username.length() <= 5 && username.contains("_");
}

public boolean isValidPassword(String password) {
    // Password must contain at least 8 characters, one capital letter, and one special character
    return password.length() >= 8 && password.matches(".*[A-Z].*") && password.matches(".*[!@#$%^&*()].*");
}
    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // handling code:
  String username = jTextField1.getText();
        String password = String.valueOf(jPasswordField1.getPassword());

        // login process
        if (registeredUsers.containsKey(username) && registeredUsers.get(username).equals(password)) {
            // Successful login
            // uses surname from the username (assuming username format is "firstname_surname")
            String[] parts = username.split("_");
            String surname = (parts.length > 1) ? parts[1] : "";
            // Sending personalized welcome message
            JOptionPane.showMessageDialog(this, "Welcome " + username + " " + surname + "! It's great to see you.");
        } else {
            JOptionPane.showMessageDialog(this, "Incorrect username or password.");
        }
        if (registeredUsers.containsKey(username) && registeredUsers.get(username).equals(password)) {
    // Successful login
    isLoggedIn = true;
    // Display welcome message
    JOptionPane.showMessageDialog(this, "Welcome " + username + "! to EasyKanban");
    
    // Add this code after successful login
    
     numTasks = Integer.parseInt(JOptionPane.showInputDialog("Enter the number of tasks you wish to enter:"));
int choice;
do {
    choice = displayMenu();
    switch (choice) {
        case 0:
            addTasks();
            // Handle option 1: Add tasks
            // Implement adding tasks functionality
            break;
        case 1:
            // Handle option 2: Show report
          showReport();
            break;
           
        case 2:
            JOptionPane.showMessageDialog(this, "Exiting the application.");
            System.exit(0);
            break;
      
    }
} while (choice != 2); // Continue looping until user chooses to quit
    
    if (!isLoggedIn) {
    JOptionPane.showMessageDialog(this, "Please log in first.");
}
    
} else {
    JOptionPane.showMessageDialog(this, "Incorrect username or password.");
}
                                                         
    }//GEN-LAST:event_jButton2ActionPerformed

    private void populateTestData() {
    Task task1 = new Task("Create Login", "Create a login screen", "Mike Smith", 5, "To Do");
    Task task2 = new Task("Create Add Features", "Add new features", "Edward Harrison", 8, "Doing");
    Task task3 = new Task("Create Reports", "Generate reports", "Samantha Paulson", 2, "Done");
    Task task4 = new Task("Add Arrays", "Implement arrays", "Glenda Oberholzer", 11, "To Do");

    tasks.put(task1.getTaskId(), task1);
    tasks.put(task2.getTaskId(), task2);
    tasks.put(task3.getTaskId(), task3);
    tasks.put(task4.getTaskId(), task4);

    developerNames.add("Mike Smith");
    developerNames.add("Edward Harrison");
    developerNames.add("Samantha Paulson");
    developerNames.add("Glenda Oberholzer");

    taskNames.add("Create Login");
    taskNames.add("Create Add Features");
    taskNames.add("Create Reports");
    taskNames.add("Add Arrays");

    taskDescriptions.add("Create a login screen");
    taskDescriptions.add("Add new features");
    taskDescriptions.add("Generate reports");
    taskDescriptions.add("Implement arrays");

    taskDurations.add(5);
    taskDurations.add(8);
    taskDurations.add(2);
    taskDurations.add(11);

    taskStatuses.add("To Do");
    taskStatuses.add("Doing");
    taskStatuses.add("Done");
    taskStatuses.add("To Do");

    taskIDs.add(task1.createTaskID());
    taskIDs.add(task2.createTaskID());
    taskIDs.add(task3.createTaskID());
    taskIDs.add(task4.createTaskID());
}
    
    
    private void jPasswordField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jPasswordField1ActionPerformed
        // auto generated code from jform:
    }//GEN-LAST:event_jPasswordField1ActionPerformed
                        


    public static void main(String args[]) {
        
        
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(LoginApplication.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        
        //</editor-fold>

        /* makes the form visible */
        java.awt.EventQueue.invokeLater(() -> {
            new LoginApplication().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPasswordField jPasswordField1;
    private javax.swing.JTextField jTextField1;
    // End of variables declaration//GEN-END:variables
}

